<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((["title", "section_title" => "Menu"]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((["title", "section_title" => "Menu"]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link rel="stylesheet" type="text/css"
          href="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1/src/regular/style.css" />
    <link rel="stylesheet" type="text/css"
          href="https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.1/src/fill/style.css" />
    <title><?php echo e($title); ?></title>
</head>
<body class="bg-zinc-100">
    <main>
        <nav>
            <header x-data="{ open: false }"
                class="flex items-center justify-between sm:justify-start gap-8 bg-white border-b 
                border-zinc-300 sticky top-0 px-3 sm:px-8 py-4">
                <h2 class="text-lg sm:text-xl font-bold">Student Management</h2>

                
                <ul class="hidden sm:flex">
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>"
                           class="<?php echo e(request()->is('dashboard') ? 'text-black' : 'text-zinc-500'); ?> block px-2 py-1 rounded font-semibold hover:text-black text-sm">
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('students.index')); ?>"
                           class="<?php echo e(request()->is('students') ? 'text-black' : 'text-zinc-500'); ?> block px-2 py-1 rounded font-semibold hover:text-black text-sm">
                            Students
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('majors.index')); ?>"
                           class="<?php echo e(request()->is('majors') ? 'text-black' : 'text-zinc-500'); ?> block px-2 py-1 rounded font-semibold hover:text-black text-sm">
                            Majors
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('students.index')); ?>"
                           class="<?php echo e(request()->is('profile') ? 'text-black' : 'text-zinc-500'); ?> block px-2 py-1 rounded font-semibold hover:text-black text-sm">
                            Profile
                        </a>
                    </li>
                </ul>

                
                <button x-on:click="open = !open" class="block sm:hidden bg-slate-50 border 
                border-slate-400 p-2">
                    <i class="ph ph-list block text-slate-400"></i>
                </button>

                
                <div x-show="open" class="bg-white border border-zinc-300 shadow-lg sm:hidden 
                absolute top-12 right-3">
                    <ul class="flex flex-col gap-2">
                        <li x-on:click="open = !open">
                            <a href="<?php echo e(route('dashboard')); ?>"
                               class="block px-4 py-2 text-zinc-600 text-sm hover:bg-gray-100">
                                Dashboard
                            </a>
                        </li>
                        <li x-on:click="open = !open">
                            <a href="<?php echo e(route('students.index')); ?>"
                               class="block px-4 py-2 text-zinc-600 text-sm hover:bg-gray-100">
                                Students
                            </a>
                        </li>
                        <li x-on:click="open = !open">
                            <a href="<?php echo e(route('majors.index')); ?>"
                               class="block px-4 py-2 text-zinc-600 text-sm hover:bg-gray-100">
                                Majors
                            </a>
                        </li>
                        <li x-on:click="open = !open">
                            <a href="<?php echo e(route('students.index')); ?>"
                               class="block px-4 py-2 text-zinc-600 text-sm hover:bg-gray-100">
                                Profile
                            </a>
                        </li>
                    </ul>
                </div>
            </header>
        </nav>

        <section class="px-3 sm:px-8 py-4 flex flex-col gap-6">
            <h1 class="text-3xl font-bold"><?php echo e($section_title); ?></h1>
            <?php echo e($slot); ?>

        </section>
    </main>
</body>
</html>
<?php /**PATH C:\KULIAHKU\Kampus Halim smst 4\WEB II\praktikum\laravel-praktikum\resources\views/components/default-layout.blade.php ENDPATH**/ ?>