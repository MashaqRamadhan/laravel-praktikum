<?php if (isset($component)) { $__componentOriginal32fd3512109ea3e722539e0ce381535c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32fd3512109ea3e722539e0ce381535c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.default-layout','data' => ['title' => 'Student','sectionTitle' => 'Students']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('default-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Student','section_title' => 'Students']); ?>
    <!-- Muhammad Haliim -->
    <?php if(session('success')): ?>
        <div class="bg-green-50 border border-green-500 text-green-500 px-3 py-2">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="flex">
        <a href="<?php echo e(route('students.create')); ?>"
            class="bg-green-50 text-green-500 border border-green-500 px-3 py-2 flex items-center gap-2">
            <i class="ph ph-plus block text-green-500"></i>
            <div>Add Student</div>
        </a>
    </div>
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white shadow">
            <thead>
                <tr class="border-b border-zinc-200 text-sm leading-normal">
                    <th class="py-3 px-6 text-left">#</th>
                    <th class="py-3 px-6 text-left">Name</th>
                    <th class="py-3 px-6 text-center">Student ID Numbers</th>
                    <th class="py-3 px-6 text-center">Gender</th>
                    <th class="py-3 px-6 text-center">Majors</th>
                    <th class="py-3 px-6 text-center">status</th>
                    <th class="py-3 px-6 text-center">Action</th>
                </tr>
            </thead>
            <tbody class="text-zinc-700 text-sm font-light">
                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b border-zinc-200 hover:bg-zinc-100">
                    <td class="py-3 px-6 text-left"><?php echo e($loop->iteration); ?></td>
                    <td class="py-3 px-6 text-left"><?php echo e($student->name); ?></td>
                    <td class="py-3 px-6 text-center"><?php echo e($student->student_id_number); ?></td>
                    <td class="py-3 px-6 text-center"><?php echo e($student->gender); ?></td>
                    <td class="py-3 px-6 text-center"><?php echo e($student->majors->name); ?></td>
                    <td class="py-3 px-6 text-center"><?php echo e($student->status); ?></td>
                    <td class="py-3 px-6">
                        <div class="flex justify-center items-center gap-1">
                            <a href="<?php echo e(route('students.show', $student->id)); ?>"
                                class="bg-blue-50 border border-blue-500 p-2 w-10 h-10 flex items-center justify-center">
                                <i class="ph ph-eye text-blue-500"></i>
                            </a>
                            <a href="<?php echo e(route('students.edit', $student->id)); ?>"
                                class="bg-yellow-50 border border-yellow-500 p-2 w-10 h-10 flex items-center justify-center">
                                <i class="ph ph-note-pencil text-yellow-500"></i>
                            </a>
                            <form onsubmit="return confirm('Are you sure?')" method="POST"
                                action="<?php echo e(route('students.destroy', $student->id)); ?>">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                        class="bg-red-50 border border-red-500 p-2 w-10 h-10 flex items-center justify-center">
                                    <i class="ph ph-trash-simple text-red-500"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center py-4 text-zinc-500">No students found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32fd3512109ea3e722539e0ce381535c)): ?>
<?php $attributes = $__attributesOriginal32fd3512109ea3e722539e0ce381535c; ?>
<?php unset($__attributesOriginal32fd3512109ea3e722539e0ce381535c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32fd3512109ea3e722539e0ce381535c)): ?>
<?php $component = $__componentOriginal32fd3512109ea3e722539e0ce381535c; ?>
<?php unset($__componentOriginal32fd3512109ea3e722539e0ce381535c); ?>
<?php endif; ?><?php /**PATH C:\KULIAHKU\Kampus Halim smst 4\WEB II\praktikum\laravel-praktikum\resources\views/students/index.blade.php ENDPATH**/ ?>